#include "list.h"
#include <stdlib.h>
#include <assert.h>

/*It is allowed to add your own helper functions. However, the already existing functiondeclarations (function heads) are not allowed to be changed.
 */

/*
 Helper function to add.
 Allocate memory for a new node. If the allocation is successful, initialize data and pointer (pointer is initialized to NULL).
 The new node (or NULL) are returned.
*/
static struct node* createListNode(const Data data)
{
    //Don't forget to test the allocation before initializing the node.
    return NULL; //Replace with correct return value
}

/*Returns an empty list - function is already completed*/
List createEmptyList(void)
{
    return NULL;
}


/*Is the list empty?
  Return 1 if empty, 0 is not.*/
int isEmpty(const List list)
{
    return -1; //Replace with correct return value
}

/*
 Add a node first in the list.
 Postcondition: The new data is first in the list (test with assert)
 */
void addFirst(List *list, const Data data)
{
    //Call createListNode to create the new node.
    //Don't forget to test that memory allocation was successful.
    //Remember that the list may be empty when a new node is added.
}

/*
 Add a node last in the list.
 Tip: When you find the right position you can use the function addFirst to insert the node.
 */
void addLast(List *list, const Data data)
{
    
}

/*
 Remove the first node from the listTa bort forsta noden i listan.
 The node shoul be linked out of the list and its memory should be freed, the rest of the list should remain.
 Precondition: the list is not empty (test with assert).
 */

void removeFirst(List *list)
{
    //Don't forget to free the memory for the removed node.
    //Remember that the head of the list needs to be updated.
}

/*
 Remove the last node in the list.
 Precondition: The list is not empty (test with assert).
 */
void removeLast(List *list)
{
    //Don't forget to free the memory for the removed node.
    //Remember to update the pointer in the new last node.
}

/*
 Remove data from list (first occurence).
 Return 1 if data is found, 0 if not found.
 Tip: when you find the correct node, you can use one of the above functions to remove the node.
 */
int removeElement(List *list, const Data data)
{
    return -1; //Replace with correct return value
}

/*
 Is the data in the list?Finns data i listan?
 Return 1 if data is found, 0 if not found.
 Remember that the list may be empty.
*/
int search(const List list, const Data data)
{
    return -1; //Replace with correct return value
}

/*Return number of nodes in list.*/
int numberOfNodesInList(const List list)
{
    return -1; //Replace with correct return value
}

/*
 Remove all nodes from the list.
 Don't forget to free the dynamic memory.
 Postcondition: The list is empty, *list is NULL (test with assert).
*/
void clearList(List *list)
{
    //All nodes must be de-allocated one by one. It is not enough to only free the list pointer.
}

/*
 Print the list.
 In the function call, stdout should be given as argument 2 (to print to the screen).
 Use fprintf to the the print out.
 This kind of print out function is more general since it can be used both to write to the console but also to external files.
*/
void printList(const List list, FILE *textfile)
{
    
}

/*
 Return the first data in the list.
 Precondition: The list is not empty (tesst with assert).
*/
Data getFirstElement(const List list)
{
    return -1; //Replace with correct return value
}

/*
 Return last data in the list
 Precondition: The list is not empty (test with assert).
*/
Data getLastElement(const List list)
{
    return -1; //Replace with correct return value
}

