#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <math.h>
#include "BSTree.h"

/*
 It is allowed to add you own helper functions. However, the existing functions may not be changed.
 Static helper functions are used by other functions in the tree (program), they should not be part
 of the interface (the used does not need to now about these).
*/


/*
 Create a tree node with the given data by allocating memory, don't forget to test and initialize
 struct members.
*/
static struct treeNode* createNode(int data)
{
   return NULL; //Replace with correct return value
}

/* Return a dynamically allocated array containing the data in the tree sorted */
static int* writeSortedToArray(const BSTree tree)
{
   /* Create a dynamic array with the correct size.
    
      Write data sorted (smallest to larges) from the tree to the aray.
      - perhaps you might need a helper function here */
   
   return NULL; //Replace with correct return value
}

/* Build a sorted, balanced tree from the array */
static void buildTreeSortedFromArray(BSTree* tree, const int arr[], int size)
{
   /* Build recursively from the middle.
      The middle element creates root in sub-tree.
      Left sub-array builds left sub-tree.
      Right sub-array builds right sub-tree.
   */
}


/* Implementation of the tree - the functions in the interface */

/* Create an empty tree - this function is completed. */
BSTree emptyTree(void)
{
   return NULL;
}


int isEmpty(const BSTree tree)
{
   return -1; //Replace with correct return value
}


/* Post-condition: data is in the tree, sorted correctly */
void insertSorted(BSTree* tree, int data)
{
   /* Remember that the tree may be empty here.
      You decide how duplicats are handled.
      Post-condition can be verifyed using find()
    */
}

/*
  When calling: use stdio as second parameter to print to the conole/screen
  It is enought that you implement the LR-orders
 */
void printPreorder(const BSTree tree, FILE *textfile)
{

}

void printInorder(const BSTree tree, FILE *textfile)
{

}

void printPostorder(const BSTree tree, FILE *textfile)
{

}


int find(const BSTree tree, int data)
{
   // Remember that the tree may be empty here
   return -1; //Replace with correct return value
}


void removeElement(BSTree* tree, int data)
{
   /* No data should/can be removed from an empty tree.
    Three cases: Leaf (no children), One child (left or right), Two children
    
    Don't forget to free the dynamic memory for the removed node.
    */
}

int numberOfNodes(const BSTree tree)
{
   return -1; //Replace with correct return value
}

int depth(const BSTree tree)
{
   return -1; //Replace with correct return value
}


int minDepth(const BSTree tree)
{
    //See math.h for useful functions
   return -1; //Replace with correct return value
}

/*
 Postcondition:
    - tree has the same number of nodes as previously
    - the depth of the tree is the same as mindepth of the tree.
 */
void balanceTree(BSTree* tree)
{
   /* Suggested algorithm:
      - write the tree sorted to a dynamic array (writeSortedToArray)
      - empty tree (freeTree)
      - build tree recursively from array (buildTreeSortedFromArray)
      - free memory for the dynamic array
    */
}

/*Postcondition: the tree is empty*/
void freeTree(BSTree* tree)
{

}



